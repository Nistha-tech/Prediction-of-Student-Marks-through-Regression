# Prediction-of-Student-Marks-through-Regression

Linear Regression with Python Scikit Learn
In this notebook we will see how the Python Scikit-Learn library for machine learning can be used to implement regression functions. We will start with simple linear regression involving two variables.

We will predict the percentage of marks that a student is expected to score based upon the number of hours they studied.

Data can be found at http://bit.ly/w-data

At the end after building our model we will test that what will be predicted score if a student study for 9.25 hrs in a
day?
![](Streamlitwebapp.JPG)

Steps:
1. Run the Prediction_of_Student_Marks_based_on_Study_Hours.ipnb file
2. Run the Streamlit.py in your CMD by this command by going to that path in which your file is saved in this way.

![](localhost.JPG)
